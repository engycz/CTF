<?php
require_once 'session.php';
require_once 'db.php';

$stmt = $pdo->query("SELECT event_time, severity, text FROM events ORDER BY event_time DESC");
$events = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <title><?= $langs['view_events'] ?></title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2><?= $langs['view_events'] ?></h2>
    <table class="table table-striped">
        <thead><tr><th>Date</th><th>Severity</th><th>Text</th></tr></thead>
        <tbody>
        <?php foreach ($events as $event): ?>
            <tr>
                <td><?= htmlspecialchars($event['event_time']) ?></td>
                <td><?= $event['severity'] ?></td>
                <td><?= $event['text'] ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <a href="index.php" class="btn btn-secondary"><?= $langs['menu'] ?></a>
</div>
</body>
</html>
