<?php
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = '" . $_POST['username'] . "'");
    $stmt->execute();
    $user = $stmt->fetch();

    if ($user) {
        if(hash('sha1', $password) === $user['password_hash']) {
        $_SESSION['user'] = $username;
        $stmt = $pdo->prepare("INSERT INTO login_logs (username, login_time) VALUES (?, NOW())");
        $stmt->execute([$username]);
        
        $entry = date('Y-m-d H:i:s') . " | " . $username . " | " . $_SERVER['REMOTE_ADDR'] . "\n";
        file_put_contents(LOGINS, $entry, FILE_APPEND | LOCK_EX);

        header('Location: index.php');
        exit;
        }
        else {
            $error = $langs['password_incorrect'];
        }
    } else {
        $error = $langs['user_not_found'];
    }
}
?>
<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <title><?= $langs['login'] ?></title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <div class="alert alert-warning" role="alert">
                        <?= $langs['test_instance'] ?>
                    </div>
                    <h4 class="card-title text-center"><?= $langs['login'] ?></h4>
                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger"><?= $error ?></div>
                    <?php endif; ?>
                    <form method="post">
                        <div class="form-group">
                            <label><?= $langs['username'] ?></label>
                            <input type="text" name="username" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label><?= $langs['password'] ?></label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block"><?= $langs['submit'] ?></button>
                    </form>
                    <div class="text-center mt-3">
                        <a href="?lang=cs">Čeština</a> | <a href="?lang=en">English</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
