<?php
require_once 'session.php';
require_once 'db.php';

$stmt = $pdo->query("SELECT username, login_time FROM login_logs ORDER BY login_time DESC");
$logs = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <title><?= $langs['view_logs'] ?></title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2><?= $langs['view_logs'] ?></h2>
    <table class="table table-striped">
        <thead><tr><th>Username</th><th>Login Time</th></tr></thead>
        <tbody>
        <?php foreach ($logs as $log): ?>
            <tr>
                <td><?= htmlspecialchars($log['username']) ?></td>
                <td><?= $log['login_time'] ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <a href="index.php" class="btn btn-secondary"><?= $langs['menu'] ?></a>
</div>
</body>
</html>
