<?php
require_once 'session.php';
?>
<!DOCTYPE html>
<html lang="<?= $_SESSION['lang'] ?>">
<head>
    <meta charset="UTF-8">
    <title><?= $langs['menu'] ?></title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2><?= $langs['menu'] ?></h2>
    <ul class="list-group">
        <?php if ($_SESSION['user'] === 'admin'): ?>
            <li class="list-group-item"><a href="admin_tools.php"><?= $langs['admin_tools'] ?></a></li>
            <li class="list-group-item"><a href="./tools/adminer-5.3.0-mysql.php">DB manager</a></li>
        <?php endif; ?>
        <li class="list-group-item"><a href="logs.php"><?= $langs['view_logs'] ?></a></li>
        <li class="list-group-item"><a href="events.php"><?= $langs['view_events'] ?></a></li>
        <li class="list-group-item"><a href="logout.php"><?= $langs['logout'] ?></a></li>
    </ul>
</div>
</body>
</html>
