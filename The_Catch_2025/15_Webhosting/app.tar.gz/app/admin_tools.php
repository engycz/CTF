<?php
require_once 'session.php';

if ($_SESSION['user'] !== 'admin') {
    http_response_code(403);
    echo $langs['access_denied'];
    exit;
}

$output = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['lines'])) {
        $lines = $_POST['lines'];
        $output = shell_exec("/usr/bin/tac " . LOGINS . "| head -n " . escapeshellcmd($lines));
    }
}
?>
<!DOCTYPE html>
<html lang="<?= $_SESSION['lang'] ?>">
<head>
    <meta charset="UTF-8">
    <title><?= $langs['admin_tools'] ?></title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2><?= $langs['admin_tools'] ?></h2>

    <form method="post" class="mb-4">
        <div class="form-group">
            <label><?= $langs['file'] ?></label>
            <input type="text" name="file" class="form-control" disabled="disabled" value="<?= LOGINS ?>">
        </div>
        <div class="form-group">
            <label><?= $langs['lines'] ?></label>
            <input type="text" name="lines" value="10" class="form-control" min="1" max="1000">
        </div>
        <button type="submit" class="btn btn-warning"><?= $langs['show_head'] ?></button>
    </form>

    <pre class="bg-light p-3 border"><?= htmlspecialchars($output) ?></pre>

    <a href="index.php" class="btn btn-secondary"><?= $langs['back'] ?></a>
</div>
</body>
</html>
