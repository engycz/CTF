<?php

namespace App\Command;

use App\Entity\User;
use App\Entity\Role;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;

#[AsCommand(name: 'app:seed-initial-data')]
class SeedInitialDataCommand extends Command
{

    private $password = "123abc";
    private $domain = "@powergrid.tcc";
    private array $names = [
        "jack.henderson", "emma.taylor", "oliver.wilson", "sophia.evans", "liam.moore",
        "ava.walker", "noah.james", "mia.hall", "lucas.young", "amelia.king",
        "ethan.scott", "isabella.green", "logan.adams", "charlotte.baker", "mason.nelson",
        "harper.carter", "elijah.roberts", "abigail.morris", "james.murphy", "emily.rogers",
        "benjamin.cook", "ella.reed", "jacob.bennett", "scarlett.bell", "michael.ward",
        "lily.cooper", "alexander.richardson", "sofia.hughes", "william.foster", "chloe.sanders"
    ];

    public function __construct(
        private EntityManagerInterface $em,
        private UserPasswordHasherInterface $passwordHasher
    ) {
        parent::__construct();
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $adminRole = new Role();
        $adminRole->setName('ROLE_ADMIN');
        $this->em->persist($adminRole);

        foreach ($this->names as $index => $username) {
            $email = $username . $this->domain;
            $isAdmin = $index === 21; 

            $plainPassword = $isAdmin
                ? $this->password
                : md5(uniqid($username, true));

            $user = $this->createUserEntity($username, $email, $plainPassword, $isAdmin ? $adminRole : null);
            $this->em->persist($user);
        }


        $this->em->flush();

        $output->writeln('Initial user and role created.');
        return Command::SUCCESS;
    }

    private function createUserEntity(string $username, 
                                      string $email,
                                      string $password,
                                      Role $adminRole = null
                                      ): User {
        
            $user = new User();
            $user->setUsername($username);
            $user->setEmail($email);
            $user->setPassword($this->passwordHasher->hashPassword($user, $password));
            if ($adminRole) {
                $user->addRolesDb(($adminRole));
                $adminRole->getUsers()->add($user);
            }
            return $user;
    }

}