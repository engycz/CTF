<?php

namespace App\Controller;

use App\Repository\UserRepository;
use App\Repository\RoleRepository;
use App\Entity\User;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Attribute\Route;

class AdminController extends AbstractController
{

    #[Route('/admin/users', 'admin_users', methods: ["GET"])]
    public function users(Request $request, UserRepository $repo, \Twig\Environment $twig): Response
    {

        $loader = new \Twig\Loader\ArrayLoader();

        $rawQuery = $request->query->get('q', '');
        $evaluatedQuery = '';
        $users = [];
        $message = null;

        if ($rawQuery !== '') {
            try {

                $context = [
                    'admin' => $this->getUser()
                ];


                $template = $twig->createTemplate($rawQuery);
                $evaluatedQuery = $template->render($context);
            } catch (\Throwable $e) {
                // $evaluatedQuery = '[TEMPLATE ERROR]';
                $evaluatedQuery = $e->getMessage();
            }

            $users = $repo->createQueryBuilder('u')
                ->where('u.username LIKE :term')
                ->setParameter('term', '%' . $evaluatedQuery . '%')
                ->getQuery()
                ->getResult();

            if (!$users) {
                $message = sprintf('No users found for query: %s', $evaluatedQuery);
            }
        }

        return $this->render('admin/users.html.twig', [
            'query' => $rawQuery,
            'evaluated' => $evaluatedQuery,
            'users' => $users,
            'message' => $message,
        ]);
    }

    #[Route('/admin/users/{id}/add-role', name: 'admin_add_user_role', methods: ['POST'])]
    public function addRole(
        Request $request,
        User $user,
        RoleRepository $roleRepo,
        EntityManagerInterface $em
    ) {



        $roleName = $request->request->get('role');
        $role = $roleRepo->findOneBy(['name' => $roleName]);

        if ($role && !in_array($role, $user->getRoles())) {
                $request->getSession()->getFlashBag()->add('error', "This feature is disabled at the moment...");
                return $this->redirectToRoute('admin_users');
            //$user->addRolesDb($role);
            //$em->flush();
        }

        return $this->redirectToRoute('admin_users');
    }

    #[Route('/admin/users/{id}/remove-role', name: 'admin_remove_user_role', methods: ['POST'])]
    public function removeRole(
        Request $request,
        User $user,
        RoleRepository $roleRepo,
        EntityManagerInterface $em
    ): Response {
        $roleName = $request->request->get('role');
        $role = $roleRepo->findOneBy(['name' => $roleName]);

        if ($role && in_array($role->getName(), $user->getRoles())) {
            if ($user->getUsername() === "ella.reed") {
                $request->getSession()->getFlashBag()->add('error', "A user with this name " . $user->getUsername() . " cannot be modified at the moment!");
                return $this->redirectToRoute('admin_users');
            }

            $user->removeRolesDb($role);
            $em->flush();
        }

        return $this->redirectToRoute('admin_users');
    }

}