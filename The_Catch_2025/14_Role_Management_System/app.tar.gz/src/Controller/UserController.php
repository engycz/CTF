<?php

namespace App\Controller;

use App\Entity\User;
use App\Repository\RoleRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use App\Repository\UserRepository;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Validator\Validator\ValidatorInterface;
use Symfony\Component\Validator\Constraints as Assert;

class UserController extends AbstractController
{

    #[Route('/user', name: 'signup_form', methods: ['GET'])]
    public function show(): Response
    {
        return $this->render('registration/signup.html.twig');
    }

    #[Route('/user', name: 'user_signup', methods: ['POST'])]
    public function signup(
        Request $request,
        EntityManagerInterface $em,
        UserPasswordHasherInterface $passwordHasher,
        ValidatorInterface $validator
    ): Response {

        $enabled = false;

        if (!$enabled) {
            return new Response(null, Response::HTTP_NOT_FOUND);
        }

        $data = json_decode($request->getContent(), true);

        $email = $data['email'] ?? null;
        $username = $data['username'] ?? null;
        $password = $data['password'] ?? null;

        // Validate input manually (you can also use DTO + validation group if preferred)
        $violations = $validator->validate($data, new Assert\Collection([
            'email' => [new Assert\NotBlank(), new Assert\Email()],
            'username' => [new Assert\NotBlank()],
            'password' => [new Assert\NotBlank(), new Assert\Length(min: 4)],
        ]));

        if (count($violations) > 0) {
            return $this->json(['errors' => (string) $violations], 400);
        }

        // Check for duplicate email
        $existing = $em->getRepository(User::class)->findOneBy(['email' => $email]);
        if ($existing) {
            return $this->json(['error' => 'Email already registered.'], 400);
        }

        // Create and persist user
        $user = new User();
        $user->setEmail($email);
        $user->setUsername($username);

        $hashedPassword = $passwordHasher->hashPassword($user, $password);
        $user->setPassword($hashedPassword);

        $em->persist($user);
        $em->flush();

        return $this->json(['message' => 'User created.'], 201);
    }


    #[Route('/user/{id}', name: 'get_user_by_id', methods: ['GET'])]
    public function getUserById(
        Request $request,
        UserRepository $userRepository
    ): Response {

        $userId = $request->get('id');
        
        // Check that $userId is unsigned_int (> 0) and it must be an integer not anything else

        $user = $userRepository->findUserById(intval($userId));

        if (!$user) {
            return new Response(null, Response::HTTP_NOT_FOUND);
        }

        return $this->render('user/user.html.twig', [
            'user' => $user,
        ]);
    }
}
