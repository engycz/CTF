#!/bin/sh

cd /opt/samweb
. venv/bin/activate
gunicorn --bind '0.0.0.0:8010' --workers=5 'samweb.app:create_app()' --access-logfile -
