"""samweb app"""

import os
from binascii import hexlify

from flask import (
    Blueprint,
    current_app,
    flash,
    Flask,
    redirect,
    render_template,
    session,
    url_for,
)
from flask_wtf import FlaskForm
from kubernetes import client as kclient, config as kconfig
from wtforms import SelectField, StringField, SubmitField
from wtforms.validators import InputRequired, Length, Regexp


bp = Blueprint("app", __name__)

DEFAULT_CONFIG = {
    "SECRET_KEY": os.urandom(32),
    "FLAG": "dummy_flag",
    "QUEUE_NS": "sam-queue",
    "DEFAULT_QUOTA": "1GB",
}


class KC:
    """kubernetes api client"""

    def __init__(self):
        kconfig.load_incluster_config()
        self.v1 = kclient.CoreV1Api()
        self.ns = current_app.config["QUEUE_NS"]

    def get_maps(self):
        """list all maps"""

        ret = self.v1.list_namespaced_config_map(namespace=self.ns)
        return ret.items

    def create_map(self, name, data):
        """create map as project storage assignment request"""

        body = {
            "apiVersion": "v1",
            "kind": "ConfigMap",
            "metadata": {
                "name": name,
                "namespace": self.ns,
                "annotations": {
                    "sam-operator/project_name": data["name"],
                    "sam-operator/project_quota": data["quota"],
                },
            },
            "data": data,
        }
        return self.v1.create_namespaced_config_map(namespace=self.ns, body=body)

    def get_map(self, name):
        """get project assignment config"""

        try:
            return self.v1.read_namespaced_config_map(namespace=self.ns, name=name)
        except Exception as e:
            current_app.logger.error(e)
            return None

    def get_secret(self, name):
        """get project secret"""

        try:
            return self.v1.read_namespaced_secret(namespace=self.ns, name=name)
        except Exception as e:
            current_app.logger.error(e)
            return None


def create_app(config=None):
    """app factory"""

    app = Flask("samweb")
    app.config.update(DEFAULT_CONFIG)
    if config:
        app.config.update(config)
    app.config.update(
        {
            "SECRET_KEY": os.environ.get("SECRET_KEY", app.config["SECRET_KEY"]),
            "FLAG": os.environ.get("FLAG", app.config["FLAG"]),
            "QUEUE_NS": os.environ.get("QUEUE_NS", app.config["QUEUE_NS"]),
            "DEFAULT_QUOTA": os.environ.get(
                "DEFAULT_QUOTA", app.config["DEFAULT_QUOTA"]
            ),
        }
    )
    app.register_blueprint(bp, url_prefix="/")

    return app


class RequestForm(FlaskForm):
    """request form"""
    
    name = StringField(
        "Name",
        validators=[
            InputRequired(),
            Length(min=5, max=50, message="Name must be between 5 and 50 characters long."),
            Regexp("^[A-Za-z0-9\.]+$", message="Name must contain only letters."),
        ]
    )
    quota = SelectField("Quota", choices=['1GB', '10GB', '100GB', '1TB'])
    submit = SubmitField("Submit")


@bp.route("/")
def index_route():
    """main page"""

    return render_template(
        "index.html",
        session=session,
        form=RequestForm(),
        project_list=KC().get_maps(),
    )


@bp.route("/request", methods=["POST"])
def request_route():
    """main page"""

    form = RequestForm()
    if form.validate_on_submit():
        reqdata = {
            "txid": hexlify(os.urandom(16)).decode(),
            "name": form.data["name"],
            "quota": form.data["quota"] or current_app.config["DEFAULT_QUOTA"],
        }
        session["reqdata"] = reqdata
        KC().create_map(f"request-{reqdata['txid']}", reqdata)

    return redirect(url_for("app.status_route"))


@bp.route("/status")
def status_route():
    """status route"""

    if "reqdata" not in session:
        flash("No pending request", "danger")
        return redirect(url_for("app.index_route"))

    reqdata = session["reqdata"]
    return render_template(
        "status.html",
        project_config=KC().get_map(f"request-{reqdata['txid']}"),
        project_secret=KC().get_secret(f"request-{reqdata['txid']}"),
    )


@bp.route("/reset")
def reset_route():
    """reset appdata from session"""

    session.pop("reqdata", None)
    return redirect(url_for("app.index_route"))
