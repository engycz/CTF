export KUBERNETES_SERVICE_HOST="kubernetes.default.svc.cluster.local"
export KUBERNETES_SERVICE_PORT="443"
export KUBERNETES_SERVICE_PORT_HTTPS="443"
FLASK_APP=samweb.app flask run --debug
