#!/usr/bin/env python3

import json
import os
import subprocess
import sys
from pathlib import Path
from random import choice as random_choice
from secrets import token_hex


QUEUE_NS = "sam-queue"

CONFIG = f"""
configVersion: v1
kubernetes:
  - apiVersion: v1
    kind: ConfigMap
    executeHookOnEvent:
      - Added
      - Deleted
    namespace:
      nameSelector:
        matchNames:
          - {QUEUE_NS}
    allowFailure: true
"""

UPDATE_TEMPLATE = """
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: "{name}"
  namespace: "{queue_ns}"
data:
  storage: "{storage}"
---
apiVersion: v1
kind: Secret
metadata:
  name: "{name}"
  namespace: "{queue_ns}"
stringData:
  storage: "{storage}"
  access_token: "{access_token}"
  quota: "{quota}"
"""

MANAGED_STORAGE = [
    "storage-hal-01",
    "storage-hal-02",
    "storage-hal-03",
    "storage-hal-04",
    "storage-hal-05",
    "storage-hal-06",
    #    "storage-hal-07",
    #    "storage-hal-08",
]


def config():
    print(CONFIG)


def process_one(ctx):
    if ctx["type"] != "Event":
        return
    if ctx["object"]["kind"] != "ConfigMap":
        return
    if not ctx['object']['metadata']['name'].startswith('request-'):
        return

    if ctx["watchEvent"] == "Added":
        print(f"Added {ctx['object']['kind']} {ctx['object']['metadata']['name']}")

        pname = ctx['object']['metadata']['name']
        # TODO: assign storage accounting it's utilization and provision the token
        storage = random_choice(MANAGED_STORAGE)
        access_token = token_hex(20)
        pquota = ctx['object']['metadata']['annotations']['sam-operator/project_quota']

        subprocess.run(
            ["kubectl", "apply", "-f", "-"],
            input=UPDATE_TEMPLATE.format(
                name=ctx['object']['metadata']['name'],
                queue_ns=QUEUE_NS,
                storage=storage,
                access_token=access_token,
                quota=pquota,
            ).encode()
        )

    elif ctx["watchEvent"] == "Deleted":
        print(f"Deleted {ctx['object']['kind']} {ctx['object']['metadata']['name']}")
 
        pname = ctx['object']['metadata']['name']
        subprocess.run(["kubectl", "delete", "secret", "--ignore-not-found=true", "-n", QUEUE_NS, pname])

    else:
        print("WARN: invalid watchevent type")

    return


def process():
    contexts = json.loads(Path(os.environ["BINDING_CONTEXT_PATH"]).read_text(encoding='utf-8'))
    for item in contexts:
        process_one(item)


if __name__ == "__main__":
    if len(sys.argv)>1 and sys.argv[1] == "--config":
        config()
    else:
        process()
