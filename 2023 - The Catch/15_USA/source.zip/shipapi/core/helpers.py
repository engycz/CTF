import time

def current_time_ms():
    return int(time.time()*1000)

