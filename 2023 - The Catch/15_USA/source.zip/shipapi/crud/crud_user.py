from typing import Any, Dict, Optional, Union

from sqlalchemy.orm import Session

from shipapi.crud.base import CRUDBase

from shipapi.core.helpers import current_time_ms
from shipapi.models.user import User
from shipapi.schemas.user import UserCreate, UserUpdate
from shipapi.core.security import get_password_hash


class CRUDUser(CRUDBase[User, UserCreate, UserUpdate]):
    def get_by_email(self, db: Session, *, email: str) -> Optional[User]:
        return db.query(User).filter(User.email == email).first()

    def update(
        self, db: Session, *, db_obj: User, obj_in: Union[UserUpdate, Dict[str, Any]]
    ) -> User:
        if isinstance(obj_in, dict):
            update_data = obj_in
        else:
            update_data = obj_in.dict(exclude_unset=True)

        if "password" in update_data.keys():
            pw = get_password_hash(update_data['password'])
            update_data.pop("password")
            update_data['hashed_password'] = pw


        return super().update(db, db_obj=db_obj, obj_in=update_data)


    def create(self, db: Session, *, obj_in: UserCreate) -> User:
        if type(obj_in) is not dict:
            create_data = obj_in.dict()
        else:
            create_data = obj_in
            obj_in = UserCreate.parse_obj(obj_in)
        create_data.pop("password")
        create_data["time_created"] = current_time_ms()
        db_obj = User(**create_data)
        db_obj.hashed_password = get_password_hash(obj_in.password)
        db.add(db_obj)
        db.commit()
        return db_obj


    def admin(self, user: User) -> bool:
        return user.admin


user = CRUDUser(User)

