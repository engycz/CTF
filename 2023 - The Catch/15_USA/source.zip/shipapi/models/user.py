from sqlalchemy import Integer, String, Column, Boolean
from sqlalchemy.orm import relationship

from shipapi.db.base_class import Base


class User(Base):
    #  def as_dict(self):
    #     return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    id = Column(Integer, primary_key=True, index=True)
    guid = Column(String, index=False)
    email = Column(String, index=True, nullable=False)
    date = Column(Integer, nullable=True)
    time_created = Column(Integer, nullable=True)
    admin = Column(Boolean, default=False)
    hashed_password = Column(String, nullable=False)
    last_update = Column(Integer, index=False, nullable=True)

