package tcc.rgame;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.stream.Collectors;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

public class App {
    HttpServer server = null;

    public App() {}

    public void run() throws IOException {
        this.server = HttpServer.create(new InetSocketAddress(8000), 0);
        this.server.createContext("/", new IndexHandler());
        this.server.createContext("/score", new ScoreHandler());
        this.server.setExecutor(null); // creates a default executor
        server.start();
    }

    public void shutdown() {
        this.server.stop(1);
    }

    public static void main(String[] args) throws Exception {
        App instance = new App();
        instance.run();
    }

    static class ScoreHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange t) throws IOException {
            String response = "{\"message\": \"Nice score !\"}";

            t.getResponseHeaders().set("Content-type", "application/json; charset=UTF-8");
            t.getResponseHeaders().set("X-Server", "Java/" + System.getProperty("java.version"));
            t.sendResponseHeaders(200, response.length());
            OutputStream os = t.getResponseBody();
            os.write(response.getBytes());
            os.close();
        }
    }

    static class IndexHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange t) throws IOException {
            String response = new BufferedReader(
                new InputStreamReader(
                    getClass().getResourceAsStream("/index.html"), StandardCharsets.UTF_8
                )
            ).lines().collect(Collectors.joining());

            t.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
            t.getResponseHeaders().set("X-Server", "Java/" + System.getProperty("java.version"));
            t.sendResponseHeaders(200, response.length());
            OutputStream os = t.getResponseBody();
            os.write(response.getBytes());
            os.close();

            // TODO request logging
        }
    }
}