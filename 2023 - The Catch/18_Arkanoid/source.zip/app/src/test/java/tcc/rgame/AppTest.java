package tcc.rgame;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.util.stream.Collectors;

import static org.junit.Assert.*;
import org.junit.Test;

public class AppTest {

    public String doRequest(String urlarg) throws IOException {
        String response = new BufferedReader(
            new InputStreamReader(
                new URL(urlarg).openConnection().getInputStream()
            )
        ).lines().collect(Collectors.joining());

        //System.out.println("DEBUG: " + response);
        return response;
    }

    @Test
    public void testJavaVersion()  {
        assertEquals(System.getProperty("java.version"), "1.8.0_144");
    }

    @Test
    public void testRoutes() throws IOException {
        App instance = new App();
        instance.run();

        String response = "";

        response = this.doRequest("http://localhost:8000/score");
        assertEquals("{\"message\": \"Nice score !\"}", response);

        response = this.doRequest("http://localhost:8000/");
        assertTrue(response.contains("Gamedev Canvas Workshop - lesson 10: finishing up"));

        instance.shutdown();
    }
}