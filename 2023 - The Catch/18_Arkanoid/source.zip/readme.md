# tcc-rgame

```
./gradlew run
```